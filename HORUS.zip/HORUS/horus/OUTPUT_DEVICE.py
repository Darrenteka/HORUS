import RPi.GPIO as GPIO
from flask import Flask, request

## SETUP VARIABLES ##
pins = list() # list containing the gpio numbers
translator = dict() # dictionary containing the translations 
#####################

app = Flask(__name__)

# Set up GPIO pins
GPIO.setmode(GPIO.BOARD)
for each in pins :
	GPIO.setup(each, GPIO.OUT)

@app.route('/data', methods=['POST'])
def process_data():

	data = request.get_json()

    	# Convert data to numbers
	global translator
    	nums = [translator.get(x, 0) for x in data]

    	# Send data as electrical signals through GPIO pins
	count = 0
	for pin in pins :
		GPIO.output(pin, nums[count])
		count += 1

    	return 'Data processed successfully'

if __name__ == '__main__':
    	app.run(host='0.0.0.0', port=80)