import requests
import time 

GPIO.setmode(GPIO.BOARD)
####### SETUP OPTIONS ########
			                 #
# pins to be used for input  #
input_pins = list()	         #
		                     #
# server to send data to     #
url = ""	                 #
description = ''             #
##############################

# Set pins to be inputs
for pin in input_pins:
    GPIO.setup(pin, GPIO.IN)

# send the input data to the server
def send_data(data):
    requests.post(url, data=data)

# Continuously monitor the input pins and send data when there is a change
while True:
    input_data = {}

    for pin in input_pins:
        input_data[str(pin)] = GPIO.input(pin) # pin: input <= format

    send_data(input_data)

	#sleep for x minutes
	time.sleep(x) # x = one minute