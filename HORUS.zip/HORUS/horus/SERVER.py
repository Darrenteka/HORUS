# Import necessary libraries
from flask import Flask, request
import openai

# Initialize Flask app
app = Flask(__name__)

###### SETUP VARIABLES ####################################################
openai.api_key = "" # openai token                                        #
dictionary = {"purpose": "","output devices":list()} # machine description#
###########################################################################

### code for sending data #####
def send_data(url,data):
    requests.post(url, data=data)

# route for receiving data
@app.route('/api', methods=['POST'])
def api():
	# input
    	input_data = request.json['input_data']
    	global dictionary
    	# ChatGPT prompt
    	prompt = f"Please process the following input such that it{dictionary}: {input_data}." ## missing perfect prompt
    
    	# Query ChatGPT for response
    	response = openai.Completion.create(
      	engine="davinci",
     	 prompt=prompt,
      	temperature=0.5,
      	max_tokens=100,
     	top_p=1,
      	frequency_penalty=0,
      	presence_penalty=0
    	)

    	# Parse response from ChatGPT
    	output_data = response.choices[0].text.strip()

	###!!!!! missing code to parse the data into a list dats
    	dats = None
	############

    	# Pass output data to other devices
    	for device in dictionary['output devices']:	
		# Send output data to each device
        	send_data(device,dats[device])
        
    return 'done'

if __name__ == '__main__':
    app.run()